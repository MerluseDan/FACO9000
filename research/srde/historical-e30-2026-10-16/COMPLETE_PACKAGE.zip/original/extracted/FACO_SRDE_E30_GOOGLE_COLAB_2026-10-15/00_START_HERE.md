# FACO SRDE Experiment 30: Google Colab Real-Model Benchmark Handoff
2026-10-15 | Prepared, offline-tested, **real Qwen run pending user-started Colab runtime**.

## One-file Google GPU launch

1. Download `FACO_SRDE_E30_GOOGLE_COLAB.ipynb` from the chat attachment.
2. Open https://colab.research.google.com/ . Choose **Upload notebook**, select the file.
3. **Runtime → Change runtime type → GPU**, ideally **T4 GPU**, depending on availability.
4. Choose **Runtime → Run all**. The notebook downloads Qwen/Qwen2.5-1.5B-Instruct from Hugging Face and runs a preflight and the preregistered main comparison on the Google GPU. It does not require your PC's GPU.
5. Download the ZIP exported by the last notebook cell and attach it to the SRDE conversation so that the actual model scores can be reviewed.

**Default:** 4 preflight calls + 320 main calls (80 questions × 4 retrieval methods) under equal 320-token retrieved context ceiling. Optional 160-call shifted confirmation, switched off by default. Each inference call is checkpointed. The notebook offers optional Google Drive persistence if selected *before* running so interrupted sessions can resume on new Google runtimes.

**No cloud GPU has been provisioned from this assistant environment, and no newly generated Qwen responses are included here.** `results/main_offline/` and `results/confirmation_offline/` contain retrieval-only metrics, not real-model correctness or measured GPU performance.

## Included
- `FACO_SRDE_E30_GOOGLE_COLAB.ipynb`: fully self-contained Google Colab notebook with all test/engine source embedded.
- `source/e30_core.py`: deterministic task generator and four retrievers, offline retrieval tests.
- `source/e30_persistence.py`: immutable SQLite evidence store, reopened before model evaluation.
- `source/e30_run_model.py`: model runner with tokenizer-based evidence budget, strict grading, progress checkpoints, paired-world bootstrap.
- `tests/test_e30.py`: 23 local tests.
- `01_FROZEN_PROTOCOL.md`: objective, model, comparator definitions, limits, failure criteria.
- `results/`: main and shifted offline-only corpus, report, and summary.
- `validation/`: local test log and release verification report.
- `MANIFEST_SHA256SUMS.txt`: hash manifest (for every payload file except itself).

## Scientific scope
The benchmark uses *new, procedurally generated synthetic software-memory worlds*, which are evaluated by a real language model when the Google notebook runs. The primary question is whether the proposed SRDE activation changes accuracy compared with an equally provisioned conventional graph with event-state resolution. This is not E29's autonomous fault-detection study and does not demonstrate all original particle properties or real-world coding benefits. Strong comparators are expected to do well; ties and negative results must be preserved.

## No hidden success claims
Archived Qwen3-4B results from earlier research cannot be transplanted into this Qwen2.5-1.5B new evaluation. Keep the two datasets, model versions, and result sources separate.
