# E30 release QA

- [x] Local source compilation and syntax check of three experiment modules.
- [x] Unit tests: 23 passing on release candidate (includes gold separation, code leaks, immutable SQLite triggers, deterministic rebuild, mock ONLY resume, strict scoring).
- [x] Main offline retrieved evidence and SHA-256 frozen, **no real model executed**.
- [x] Shifted confirmation offline retrieval and SHA-256 frozen, **no real model executed**.
- [x] Notebook generated as notebook v4 and passed `nbformat.validate`.
- [x] Embedded code cells byte-for-byte identical to tested Python source; tested by release audit.
- [x] No external activation of Google GPU or pretrained model claimed.
- [ ] **Qwen GPU preflight on Colab**, requires user-managed runtime.
- [ ] **Qwen frozen 320-call main score**, pending.
- [ ] Optional 160-call shifted confirmation, pending.

Do not recast mock unit-test answers, offline proof recall or corpus gold labels as model inference accuracy.
