"""FACO SRDE E30 real HuggingFace GPU inference runner. Colab-friendly.

No remote execution occurs until a person starts a Google Colab runtime.
Do not label output a completed experiment without model_run.json and QA.
"""
import argparse
import hashlib
import json
import os
import platform
import random
import re
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

from e30_persistence import persist_and_reload
from e30_core import (MAIN_SEEDS,CONFIRM_SEEDS,METHODS,PROTOCOL_ID,TOKEN_BUDGET,
                     canonical,data,evidence,prompt,sha,save_offline)

MODEL_DEFAULT = 'Qwen/Qwen2.5-1.5B-Instruct'
MAX_NEW_TOKENS = 80

def strictly_grade(raw, ended, gold):
    """No lenient salvage: an invalid or truncated answer is not a success."""
    if not ended:return {'status':'TRUNCATED','answer':None,'correct':False}
    try:
        obj=json.loads(raw)
    except (TypeError,ValueError):
        return {'status':'INVALID_JSON','answer':None,'correct':False}
    if not isinstance(obj,dict) or list(obj.keys())!=['answer'] or not isinstance(obj['answer'],str):
        return {'status':'INVALID_SCHEMA','answer':None,'correct':False}
    val=obj['answer']
    if not re.fullmatch(r'(?:[A-Z][A-Z2-9]{7}|UNKNOWN)',val):
        return {'status':'INVALID_VALUE','answer':val,'correct':False}
    return {'status':'CORRECT' if val==gold else 'WRONG','answer':val,'correct':val==gold}

def bootstrap_paired(rows,a='srde_activated',b='graph_state',n=10000):
    """Paired worlds are the resampling unit, not correlated individual tasks."""
    per=defaultdict(dict)
    for r in rows:per[r['world']].setdefault(r['method'],[]).append(int(r['correct']))
    pairs=[]
    for w,item in per.items():
        if a in item and b in item:
            assert len(item[a])==len(item[b])
            pairs.append(statistics.mean(item[a])-statistics.mean(item[b]))
    if not pairs:return {'n_paired_worlds':0,'delta':None,'ci95':None}
    rng=random.Random(3040001)
    samples=sorted(statistics.mean(rng.choices(pairs,k=len(pairs))) for _ in range(n))
    return {'n_paired_worlds':len(pairs),'delta':statistics.mean(pairs),
            'ci95':[samples[int(.025*n)],samples[min(n-1,int(.975*n))]]}

def summarize(rows):
    s={}
    for m in METHODS:
        rs=[r for r in rows if r['method']==m]
        if not rs:continue
        s[m]={'n':len(rs),'correct':sum(bool(x['correct']) for x in rs),
              'accuracy':sum(bool(x['correct']) for x in rs)/len(rs),
              'truncated':sum(x['status']=='TRUNCATED' for x in rs),
              'invalid':sum(x['status'].startswith('INVALID') for x in rs),
              'wrong':sum(x['status']=='WRONG' for x in rs),
              'mean_inference_seconds':statistics.mean(x['seconds'] for x in rs),
              'mean_retrieval_seconds':statistics.mean(x['retrieval_seconds'] for x in rs),
              'mean_evidence_tokens':statistics.mean(x['evidence_tokens'] for x in rs),
              'mean_actual_input_tokens':statistics.mean(x['input_tokens'] for x in rs),
              'known_accuracy':(statistics.mean(bool(x['correct']) for x in rs if x['gold']!='UNKNOWN')
                               if any(x['gold']!='UNKNOWN' for x in rs) else None),
              'unknown_accuracy':(statistics.mean(bool(x['correct']) for x in rs if x['gold']=='UNKNOWN')
                                 if any(x['gold']=='UNKNOWN' for x in rs) else None)}
    return {'methods':s,'paired_srde_minus_graph_state':bootstrap_paired(rows),
            'note':'Strict exact JSON. Invalid/truncated counted wrong. Worlds clustered in bootstrap.'}

def load_backend(model_id, allow_cpu=False):
    try:
        import torch
        import transformers
        from transformers import AutoModelForCausalLM,AutoTokenizer
    except ImportError as e:
        raise RuntimeError('Install transformers and accelerate in Google Colab first') from e
    if not torch.cuda.is_available() and not allow_cpu:
        raise RuntimeError('No CUDA GPU detected. In Colab choose Runtime > Change runtime type > T4 GPU, '
                           'then rerun. No CPU benchmark silently substituted.')
    print('Loading model (Google Colab may download model files once):', model_id,flush=True)
    tok=AutoTokenizer.from_pretrained(model_id,trust_remote_code=False)
    model=AutoModelForCausalLM.from_pretrained(model_id,device_map='auto',torch_dtype='auto',trust_remote_code=False)
    model.eval()
    eos=model.generation_config.eos_token_id
    eos_set=set(eos if isinstance(eos,(list,tuple)) else [eos])
    eos_set.discard(None)
    def count(text):return len(tok.encode(text,add_special_tokens=False))
    def infer(task,ctx):
        p=prompt(task,ctx)
        messages=[{'role':'system','content':p['system']},{'role':'user','content':p['user']}]
        inp=tok.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_tensors='pt')
        input_count=inp.shape[1]
        # model.device works for single-GPU model; do not force CPU computation.
        dev=model.device
        t0=time.perf_counter()
        with torch.inference_mode():
            out=model.generate(inp.to(dev),max_new_tokens=MAX_NEW_TOKENS,do_sample=False,
                               pad_token_id=tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id)
        elapsed=time.perf_counter()-t0
        generated=out[0,input_count:].tolist()
        raw=tok.decode(generated,skip_special_tokens=True).strip()
        ended=bool(generated and generated[-1] in eos_set)
        if not ended and len(generated)<MAX_NEW_TOKENS:
            # Some models define multiple EOT tokens, which must be reported.
            # Don't claim truncated if generation ended before the max.
            ended=True
        return {'raw':raw,'ended':ended,'seconds':elapsed,'input_tokens':int(input_count),
                'output_tokens':len(generated)}
    device={'torch':torch.__version__,'transformers':transformers.__version__,
            'cuda':torch.version.cuda,'cuda_available':torch.cuda.is_available(),
            'gpu_name':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            'gpu_vram':torch.cuda.get_device_properties(0).total_memory if torch.cuda.is_available() else None}
    return count,infer,device

def selected_tasks(corpus,mode):
    tasks=[]
    for w in corpus['worlds']:
        for t in w['tasks']:
            if mode=='quick' and t['scenario'] not in ('current_route','linked_policy','poisoned_policy','conflicting_override'):
                continue
            if mode=='preflight' and (w is not corpus['worlds'][0] or t['scenario']!='current_route'):
                continue
            tasks.append((w,t))
    rng=random.Random(987123)
    items=[(w,t,m) for w,t in tasks for m in METHODS]
    rng.shuffle(items)
    return items

def run(outdir,mode,model_id,allow_cpu=False):
    seeds=CONFIRM_SEEDS if mode=='confirmation' else MAIN_SEEDS
    corpus=data(seeds)
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    corpus_path=out/'corpus.json'
    if corpus_path.exists():
        prior=json.loads(corpus_path.read_text())
        if prior.get('sha256')!=corpus['sha256']:raise RuntimeError('Resume refused: corpus changed')
    corpus_path.write_text(json.dumps(corpus,indent=2)+'\n')
    corpus=persist_and_reload(corpus,out/'evidence_memory.sqlite')
    info={'protocol':PROTOCOL_ID,'mode':mode,'model_id':model_id,'corpus_sha256':corpus['sha256'],
          'methods':METHODS,'evidence_token_budget':TOKEN_BUDGET,'max_new_tokens':MAX_NEW_TOKENS,
          'scoring':'exact one-key JSON; known code or UNKNOWN; stop not length',
          'python':platform.python_version()}
    meta_path=out/'run_metadata.json'
    if meta_path.exists():
        old=json.loads(meta_path.read_text())
        if any(old.get(k)!=info.get(k) for k in ('protocol','mode','model_id','corpus_sha256','evidence_token_budget','max_new_tokens')):
            raise RuntimeError('Resume refused: protocol/model/budget changed')
    count,infer,device=load_backend(model_id,allow_cpu)
    info.update(device)
    meta_path.write_text(json.dumps(info,indent=2)+'\n')
    checkpoint=out/'model_rows.jsonl'
    rows=[];known=set()
    if checkpoint.exists():
        for line in checkpoint.read_text().splitlines():
            if line.strip():
                record=json.loads(line)
                key=(record['task_id'],record['method'])
                if key in known:raise RuntimeError('Duplicate checkpoint record')
                known.add(key);rows.append(record)
    work=selected_tasks(corpus,mode)
    print(f'Starting {mode}: {len(work)} model calls, {len(known)} already saved.',flush=True)
    for i,(world,task,method) in enumerate(work,1):
        key=(task['id'],method)
        if key in known: continue
        retrieval_start=time.perf_counter()
        ev=evidence(world,task,method,TOKEN_BUDGET,count)
        retrieval_seconds=time.perf_counter()-retrieval_start
        if count(ev['text'])>TOKEN_BUDGET:
            raise AssertionError('Actual tokenizer budget exceeded')
        rr=infer(task,ev['text'])
        grade=strictly_grade(rr['raw'],rr['ended'],task['gold'])
        item={'world':world['world'],'task_id':task['id'],'scenario':task['scenario'],'method':method,
              'gold':task['gold'],'model_output':rr['raw'],'status':grade['status'],
              'correct':grade['correct'],'answer':grade['answer'],
              'seconds':rr['seconds'],'retrieval_seconds':retrieval_seconds,'input_tokens':rr['input_tokens'],
              'output_tokens':rr['output_tokens'],'evidence_tokens':ev['tokens'],
              'proof_hits':ev['proof_hit'],'proof_count':ev['proof_count'],
              'prompt_sha256':hashlib.sha256(canonical(prompt(task,ev['text'])).encode()).hexdigest()}
        with checkpoint.open('a') as f:
            f.write(json.dumps(item,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
        rows.append(item);known.add(key)
        print(f'[{i}/{len(work)}] {task["scenario"]} {method}: {item["status"]} ({rr["seconds"]:.2f}s)',flush=True)
    # Score only when ALL calls complete (prevents reporting interrupted partials as conclusions).
    completed=len(known)==len(work)
    report={'status':'REAL_LLM_COMPLETED' if completed else 'PARTIAL',
            'full_run':mode in ('standard','confirmation') and completed,
            'protocol':info,'total_calls':len(work),'completed_calls':len(known),
            'summary':summarize(rows)}
    (out/'model_run.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['summary'],indent=2),flush=True)
    return report

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=['offline','preflight','quick','standard','confirmation'],default='quick')
    p.add_argument('--model',default=MODEL_DEFAULT)
    p.add_argument('--out',default='e30_result')
    p.add_argument('--allow-cpu',action='store_true')
    args=p.parse_args()
    if args.mode=='offline':
        print(json.dumps(save_offline(args.out,data()),indent=2));return
    run(args.out,args.mode,args.model,args.allow_cpu)

if __name__=='__main__': main()
