"""Audit completed v3 stages against pre-run prompt manifests and immutable labels."""
import pathlib,json,hashlib,re,statistics,datetime,sys
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'e30_repair_v3/source'))
from e30_integrity import verify_freeze,file_sha
from e30_run_model import summarize
verify_freeze()
def independent_grade(raw,ended,gold):
    if not ended:return ('TRUNCATED',None,False)
    def unique(pairs):
        obj={}
        for key,value in pairs:
            if key in obj:raise ValueError('Duplicate JSON key')
            obj[key]=value
        return obj
    try:obj=json.loads(raw,object_pairs_hook=unique)
    except (TypeError,ValueError):return ('INVALID_JSON',None,False)
    if not isinstance(obj,dict) or list(obj)!=['answer'] or not isinstance(obj['answer'],str):return ('INVALID_SCHEMA',None,False)
    value=obj['answer']
    if not re.fullmatch(r'(?:[A-Z][A-Z2-9]{7}|UNKNOWN)',value):return ('INVALID_VALUE',value,False)
    return ('CORRECT' if value==gold else 'WRONG',value,value==gold)
result={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':{},'scope':'Real Qwen over synthetic software-memory questions; no real-world/detector replication claim'}
for stage,mode in [('preflight','preflight'),('main','standard'),('confirmation','confirmation')]:
    path=root/'local_results_v3'/stage
    report=json.loads((path/'model_run.json').read_text())
    expected=json.loads((root/'evidence'/(mode+'_expected_prompts.json')).read_text())
    exp={(r['task_id'],r['method']):r for r in expected}
    rows=[json.loads(l) for l in (path/'model_rows.jsonl').read_text().splitlines()]
    keys=[(r['task_id'],r['method']) for r in rows]
    assert len(keys)==len(set(keys)) and set(keys)==set(exp)
    assert report['checkpoint_sha256']==file_sha(path/'model_rows.jsonl')
    for r in rows:
        e=exp[(r['task_id'],r['method'])]
        for field in ('world','scenario','gold','prompt_sha256','input_prompt_sha256','evidence_tokens'):
            assert r[field]==e[field],(stage,field)
        assert r['evidence_tokens']<=320
        grade=independent_grade(r['model_output'],r['ended'],e['gold'])
        assert (r['status'],r['answer'],r['correct'])==grade
    runtime=report['protocol']['base_identity']['runtime']
    assert runtime['parameter_devices']==['cuda:0'] and runtime['parameter_dtypes']==['torch.float32']
    assert len(runtime['dependencies'])==46
    if stage=='preflight':assert report['status']=='PREFLIGHT_STRUCTURAL_PASS' and len(rows)==4
    else:assert report['status']=='REAL_LLM_COMPLETED' and report['full_run']
    per={}
    for method in ('lexical','temporal_graph','graph_state','srde_activated'):
        rs=[r for r in rows if r['method']==method]
        per[method]={'n':len(rs),'correct':sum(r['correct'] for r in rs),'accuracy':statistics.mean(r['correct'] for r in rs),
          'mean_inference_seconds':statistics.mean(r['seconds'] for r in rs),'mean_retrieval_seconds':statistics.mean(r['retrieval_seconds'] for r in rs),
          'mean_state_preprocessing_seconds':statistics.mean(r['state_preprocessing_seconds'] for r in rs),
          'total_state_visible_records':sum(r['state_visible_records'] for r in rs),'total_state_validity_checks':sum(r['state_validity_checks'] for r in rs),
          'peak_allocated_bytes':max(r['peak_allocated_bytes'] for r in rs),'peak_reserved_bytes':max(r['peak_reserved_bytes'] for r in rs),
          'invalid_or_truncated':sum(r['status'] not in ('CORRECT','WRONG') for r in rs)}
    result['stages'][stage]={'calls':len(rows),'exact_keys':'pass','pre_run_prompt_hashes':'all match','recomputed_grades':'all match',
        'checkpoint_sha256':file_sha(path/'model_rows.jsonl'),'methods':per,'primary':summarize(rows)['paired_srde_minus_graph_state'],'runtime':runtime}
(root/'evidence/local_v3_completed_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({stage:{'calls':d['calls'],'methods':d['methods'],'primary':d['primary']} for stage,d in result['stages'].items()},indent=2))
