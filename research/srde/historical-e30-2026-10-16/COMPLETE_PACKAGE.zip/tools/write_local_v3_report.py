"""Produce a report from completed, independently validated frozen E30 receipts."""
from pathlib import Path
import collections
import csv
import datetime
import json
import statistics

root = Path(__file__).resolve().parents[1]
v = json.loads((root / 'evidence/local_v3_completed_validation.json').read_text())
rep = json.loads((root / 'evidence/local_v3_reproducibility.json').read_text())
methods = ['lexical', 'temporal_graph', 'graph_state', 'srde_activated']
lines = [
    'FACO SRDE E30 — LOCAL COMPLETED / COLAB BLOCKED',
    'Tracker: [Faco] SRDV rollout',
    'Generated UTC: ' + datetime.datetime.now(datetime.timezone.utc).isoformat(),
    '',
    'Local outcome: four structurally valid preflight calls, all 320 main calls and',
    'all 160 independent-seed same-generator confirmation calls completed. Every',
    'expected task/method key, pre-run raw/token prompt hash and recomputed strict',
    'grade matched. All failures, invalid and wrong answers are retained.',
    'Colab outcome: exact package/runtime prepared on an observed free Tesla T4;',
    'zero model calls. Chrome control Transport closed, including a read-only',
    'check after Dan reported fixing it. No cross-platform result is available.',
    '',
    'CORRECTNESS — strict JSON; invalid/truncated responses count as wrong',
    'Method                 Main (80/method)        Confirmation (40/method)',
]
for m in methods:
    a = v['stages']['main']['methods'][m]
    b = v['stages']['confirmation']['methods'][m]
    lines.append(f'{m:22s} {a["correct"]:2d}/80 ({100*a["accuracy"]:5.2f}%)        {b["correct"]:2d}/40 ({100*b["accuracy"]:5.2f}%)')
for stage in ['main', 'confirmation']:
    s = v['stages'][stage]
    p = s['primary']
    lines.extend(['', f'{stage}: SRDE minus graph_state = {100*p["delta"]:.2f} percentage points;',
                  f'95% world-clustered percentile bootstrap interval [{100*p["ci95"][0]:.2f}, {100*p["ci95"][1]:.2f}] points,',
                  f'{p["n_paired_worlds"]} worlds, 10000 fixed-seed resamples. Exploratory small-sample intervals.',
                  'Method                 Mean inference s   Mean retrieval ms   State resolver ms   Invalid/truncated'])
    for m in methods:
        d = s['methods'][m]
        lines.append(f'{m:22s} {d["mean_inference_seconds"]:8.4f}           {1000*d["mean_retrieval_seconds"]:8.4f}            {1000*d["mean_state_preprocessing_seconds"]:8.4f}          {d["invalid_or_truncated"]}')

rows = []
validation = []
for stage in ['preflight', 'main', 'confirmation']:
    p = root / 'local_results_v3' / stage
    rs = [json.loads(l) for l in (p / 'model_rows.jsonl').read_text().splitlines()]
    rows.extend(rs)
    validation.extend(json.loads(l) for l in (p / 'validation_invocations.jsonl').read_text().splitlines())
    lines.extend(['', f'{stage}: statuses ' + json.dumps(dict(collections.Counter(r['status'] for r in rs)), sort_keys=True),
                  f'{stage}: evidence token range {min(r["evidence_tokens"] for r in rs)}–{max(r["evidence_tokens"] for r in rs)} (cap 320).'])

runtime = v['stages']['main']['runtime']
snap = json.loads((root / 'evidence/local_confirmation_resource_snapshot.json').read_text())
lines.extend([
    '', 'RESOURCE AND TIMING SCOPE',
    f'GPU: {runtime["gpu"]}; all parameters cuda:0 / float32; eager attention.',
    f'Python {runtime["python"]}; Torch {runtime["torch_build"]}; CUDA build {runtime["cuda_build"]}.',
    '46 locked dependency versions; pinned model and tokenizer revision',
    '989aa7980e4cf806f80c7fef2b1adb7bc71aa306; all eight consumed files verified.',
    'Effective generation call: do_sample=False, max_new_tokens=80; fixed seed',
    '3040001, deterministic algorithms, TF32 disabled. Inherited repetition',
    'penalty 1.1 remains active. Logged generation_config is the inherited object;',
    'the frozen call overrides its sampling/max-token/pad settings. Warnings that',
    'temperature/top-p/top-k are ignored under greedy decoding are retained.',
    'The single unpadded input uses the original pad/EOS handling; its attention-',
    'mask warning is retained. No settings were changed after main scoring began.',
    f'Peak per-call GPU allocation {max(r["peak_allocated_bytes"] for r in rows)} bytes;',
    f'peak reserved {max(r["peak_reserved_bytes"] for r in rows)} bytes.',
    f'Across 484 study calls: inference {sum(r["seconds"] for r in rows):.4f} s;',
    f'retrieval {sum(r["retrieval_seconds"] for r in rows):.4f} s;',
    f'per-call occupancy guards {sum(r["guard_seconds"] for r in rows):.4f} s.',
    f'Additional validation/persistence/prompt construction across invocations: {sum(x["seconds"] for x in validation):.4f} s.',
    'Startup load seconds (separate from inference): ' + ', '.join(str(json.loads((root/'local_results_v3'/p).read_text())['backend_load_seconds']) for p in ['startup_cost_first_invocation.json','startup_cost.json']) + '.',
    'One confirmation resource snapshot: ' + json.dumps(snap['campaign_processes']) + '; GPU: ' + snap['gpu_readout'] + '.',
    'RSS and GPU power/utilization are point-in-time observations, not peaks or',
    'integrated energy measurements. GPU totals include idle resident services.',
    'Inference timing includes CUDA synchronization. It excludes guard, startup,',
    'validation, export and operator delay. Latency is descriptive: a guard',
    'detected a competing Python workload after 160 main calls and stopped E30;',
    'brief contention between samples cannot be excluded. No other job was killed.',
    '', 'FULL-VISIBLE-WORLD PREPROCESSING',
    'Both state methods resolve the full visible world before truncating evidence.',
    'The common prompt discloses this. Their state timer and full retrieval timer',
    'include the resolver, and visible-record/recursive-validity-check counts are',
    'preserved per call. Equal evidence tokens do not mean equal preprocessing cost.',
])
for stage in ['main', 'confirmation']:
    for m in ['graph_state', 'srde_activated']:
        d = v['stages'][stage]['methods'][m]
        lines.append(f'{stage} {m}: {d["total_state_visible_records"]} cumulative visible records, {d["total_state_validity_checks"]} validity checks.')
lines.extend([
    '', 'REPRODUCIBILITY AND RESUME',
    'Main interrupted once at 160 rows by the active-unrelated-compute guard.',
    'After fresh clear occupancy samples, the unchanged campaign resumed in the',
    'same directory. The original 160-row byte prefix and original preflight/main',
    'runtime metadata hashes remain identical. Saved questions were not re-executed.',
    f'{rep["repeated_input_groups"]} repeated input-hash groups covering {rep["calls_in_repeated_groups"]} existing calls:',
    f'{rep["different_generated_token_groups"]} groups with different generated token sequences.',
    'All four preflight prompts repeated in main produced identical token sequences.',
    'This is within-run repeated-input evidence, not an independent rerun or a',
    'local/Colab reproducibility result. State-method identical prompt counts: ' + json.dumps(rep['state_method_overlap']),
    '', 'PRESERVED REPAIRS AND NEGATIVE EVIDENCE',
    'Original release: immutable ZIP CRC clean, 17 payload hashes match, 23 tests pass.',
    'Versioned repairs: strict structural preflight; complete runtime/code/model',
    'resume identity; lossless final-tail recovery and exact-key/prompt/grade checks;',
    'correct confirmation label; exact dependencies/CUDA placement; fsynced local',
    'and externally acknowledged Colab checkpoints; explicit full-world state cost.',
    'Repaired exact release regression suite: 41 tests pass. Pre-run tokenizer audit',
    'covers all 484 prompts, maximum 314 evidence tokens. No frozen scientific-code edits after main began.',
    'Preserved v2 smoke: 80 token-0 exclamation marks, no EOS, TRUNCATED. Dedicated',
    'diagnostic found finite weights but non-finite float16 layer/logits; a float32',
    'forward was finite. Separate v3 float32 freeze on both platforms was made',
    'before any main scores; successful dedicated local smoke remains excluded.',
    'Local accounting: 484 study generations (4 preflight + 320 main + 160',
    'confirmation), 2 excluded smoke generations (v2/v3), 2 diagnostic forwards.',
    'No accuracy-based question selection, retries, lenient answer salvage or pooling.',
    '', 'COLAB EXACT BLOCKER AND CONTINUATION',
    'Target: https://colab.research.google.com/drive/11EHwDJsKtEEDyD7cLAZvL-KU_pQT7TFv',
    'Browser: Dan\'s Chrome, browser 3 / tab 1600131650. Resource probe observed',
    'Tesla T4 15360 MiB, driver 580.82.07, Python 3.12.13. Exact frozen ZIP and',
    'manifest verified there; isolated 46-package install and 41-test subprocess',
    'returned success. This does not establish a successful model load or campaign.',
    'The first smoke orchestration cell failed parsing before any execution. The',
    'correction could not be entered after browser-control timeout/Transport closed.',
    'Latest read-only check still returns Transport closed. Action is blocked by',
    'unavailable transport, not denied; no corrected model launcher was executed.',
    'No paid compute, upgrade, Drive mount or new OAuth grant. Terms approval',
    'persists; no Terms dialog was shown on reload and no agent acceptance click',
    'was made. A surviving T4 session must be checked again before continuation.',
    'Use RESUME_CURRENT.txt and FACO_SRDE_E30_REPAIRED_v3_ISOLATED.ipynb. They carry',
    'the same frozen study and pause for verified external checkpoint downloads.',
    'Source-thread messaging returned thread not found; these durable Library',
    'deliverables and the platform completion notification preserve the handoff.',
    '', 'SCOPE',
    'Real Qwen inference over synthetic software-memory QA. Eight main worlds and',
    'four confirmation worlds from the same generator. No real-world validation,',
    'distribution-shift test or E29 learned-detector replication. Preserve nulls',
    'and losses. No local-versus-Colab correctness/latency/resource claim is possible',
    'until both matching platform stages have actually completed and been audited.',
    '', 'HASHES',
    'Original ZIP: 8f5c15809e59574ec6d5da15e28c81b0075f15ef7f195bc6f3ba0a9a9f2950e8',
    'Active v3 ZIP: f54a7aa865049a9c8d7771372729f8a8814e117994eff499077a38935255cc9a',
    'FREEZE.json bytes: d584521f0fcf584a974d3a7172bbe756d7c0c92383bf64d41e46e4834daf00a3',
    'Canonical manifest identity: 49f79f067bb74287566093e0024eaacba756f48816b65dd6100937ae3a7aba4b',
])
(root/'E30_LOCAL_RESULTS_REPORT.txt').write_text('\n'.join(lines)+'\n')
with (root/'comparison_status.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['platform','stage','method','calls','correct','accuracy','mean_inference_seconds','mean_retrieval_seconds','peak_allocated_bytes','status'])
    for stage in ['main','confirmation']:
        for m in methods:
            d=v['stages'][stage]['methods'][m]
            w.writerow(['local',stage,m,d['n'],d['correct'],d['accuracy'],d['mean_inference_seconds'],d['mean_retrieval_seconds'],d['peak_allocated_bytes'],'COMPLETED_VALIDATED'])
    w.writerow(['colab','all','',0,'','','','','','BLOCKED: Chrome control Transport closed; no model calls'])
status=json.loads((root/'STATUS.json').read_text())
status.update(phase='Local preflight/main/confirmation completed and independently validated; Colab browser transport blocked',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),current_report='E30_LOCAL_RESULTS_REPORT.txt',current_resume='RESUME_CURRENT.txt')
status['measured_main_calls']['local']=320;status['confirmation_calls']['local']=160
status['validation']['completed_v3_rows']='484/484 exact expected keys, pre-run prompt/token hashes, recomputed grades pass'
status['validation']['reproducibility']=f'{rep["repeated_input_groups"]} repeated input groups, {rep["different_generated_token_groups"]} token divergences'
status['local_resume']['state']='completed; original 160 rows and original runtime metadata unchanged'
(root/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
print(root/'E30_LOCAL_RESULTS_REPORT.txt')
