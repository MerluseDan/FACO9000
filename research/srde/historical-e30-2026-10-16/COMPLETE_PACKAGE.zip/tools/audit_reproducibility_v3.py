"""Post-run evidence only: no model calls and no changes to the frozen study."""
from pathlib import Path
import collections
import datetime
import hashlib
import json

root = Path(__file__).resolve().parents[1]
stages = {}
groups = collections.defaultdict(list)
for stage, count in [('preflight', 4), ('main', 320), ('confirmation', 160)]:
    folder = root / 'local_results_v3' / stage
    report = json.loads((folder / 'model_run.json').read_text())
    rows = [json.loads(x) for x in (folder / 'model_rows.jsonl').read_text().splitlines()]
    assert len(rows) == count == report['completed_calls']
    stages[stage] = rows
    for row in rows:
        groups[row['input_prompt_sha256']].append((stage, row))

repeated = [items for items in groups.values() if len(items) > 1]
different = []
for items in repeated:
    if len({tuple(row['generated_token_ids']) for _, row in items}) > 1:
        different.append([{'stage': s, 'task_id': r['task_id'], 'method': r['method'],
                           'generated_token_ids': r['generated_token_ids']} for s, r in items])

prefix = (root / 'evidence/main_first160_before_resume.jsonl').read_bytes()
assert len(prefix.splitlines()) == 160
assert (root / 'local_results_v3/main/model_rows.jsonl').read_bytes().startswith(prefix)
metadata = []
for line in (root / 'evidence/local_v3_before_resume_sha256.txt').read_text().splitlines():
    digest, path = line.split(None, 1)
    if path.endswith('run_metadata.json'):
        actual = hashlib.sha256((root / path).read_bytes()).hexdigest()
        assert actual == digest
        metadata.append({'path': path, 'sha256': actual, 'unchanged': True})

preflight_repeat = []
main = {(r['task_id'], r['method']): r for r in stages['main']}
for before in stages['preflight']:
    after = main[(before['task_id'], before['method'])]
    preflight_repeat.append({'task_id': before['task_id'], 'method': before['method'],
                             'same_input_hash': before['input_prompt_sha256'] == after['input_prompt_sha256'],
                             'same_generated_tokens': before['generated_token_ids'] == after['generated_token_ids']})

result = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Existing local calls only. No extra generation and no cross-platform claim.',
          'repeated_input_groups': len(repeated),
          'calls_in_repeated_groups': sum(map(len, repeated)),
          'different_generated_token_groups': len(different), 'different_groups': different,
          'preflight_prompts_repeated_in_main': preflight_repeat,
          'resume': {'saved_160_row_prefix_preserved': True,
                     'prefix_sha256': hashlib.sha256(prefix).hexdigest(),
                     'original_runtime_metadata': metadata},
          'state_method_overlap': {}}
for stage in ['main', 'confirmation']:
    pairs = collections.defaultdict(dict)
    for row in stages[stage]:
        pairs[row['task_id']][row['method']] = row
    result['state_method_overlap'][stage] = {
        'tasks': len(pairs),
        'identical_input_prompts': sum(v['graph_state']['input_prompt_sha256'] == v['srde_activated']['input_prompt_sha256'] for v in pairs.values()),
        'note': 'Shared prompts are retained in both frozen method totals; they are not independent new evidence.'}

out = root / 'evidence/local_v3_reproducibility.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
