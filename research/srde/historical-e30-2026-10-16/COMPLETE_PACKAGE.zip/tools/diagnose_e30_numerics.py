"""Bounded smoke-only diagnostics. Never benchmark scores; frozen package untouched."""
import pathlib,sys,json,subprocess,time,traceback
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'e30_repair_v2/source'))
from e30_integrity import atomic_json,verify_freeze
from e30_core import prompt
from e30_run_model import load_backend,MODEL_DEFAULT,gpu_guard
receipt={'scope':'One frozen fp16 forward plus one float32 diagnostic forward on the dedicated smoke prompt. No study questions or scores.'}
try:
 occupancy=subprocess.run(['nvidia-smi','pmon','-c','4','-s','um'],capture_output=True,text=True,check=True).stdout
 if 'llama-server' in occupancy:raise RuntimeError('Unrelated LLM remains resident')
 free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
 if free<8192:raise RuntimeError('Under 8 GiB free before diagnostic load')
 verify_freeze();gpu_guard()
 count,infer,runtime=load_backend(MODEL_DEFAULT);receipt['runtime']=runtime
 closure=dict(zip(infer.__code__.co_freevars,[c.cell_contents for c in infer.__closure__]))
 model=closure['model'];tok=closure['tok'];torch=closure['torch']
 task={'question':'What is the current route marker for SMOKE-C00 at tick 300?'}
 ctx='[D0000] SMOKE-C00 route=RABCDEFG valid=[100,1000) origin=official verification=signed inherits=-'
 p=prompt(task,ctx);ids=tok.apply_chat_template([{'role':'system','content':p['system']},{'role':'user','content':p['user']}],tokenize=True,add_generation_prompt=True,return_tensors='pt').to('cuda:0')
 receipt['bad_weight_tensors']=[n for n,v in model.named_parameters() if not bool(torch.isfinite(v).all())]
 stages=[]
 def hook(name):
  def inspect(module,args,out):
   x=out[0] if isinstance(out,tuple) else out
   if torch.is_tensor(x):
    stages.append({'module':name,'dtype':str(x.dtype),'all_finite':bool(torch.isfinite(x).all()),'max_abs':float(x.float().abs().max())})
  return inspect
 handles=[model.model.embed_tokens.register_forward_hook(hook('embedding'))]
 handles += [layer.register_forward_hook(hook('layer_'+str(k))) for k,layer in enumerate(model.model.layers)]
 handles += [model.model.norm.register_forward_hook(hook('final_norm'))]
 gpu_guard()
 with torch.inference_mode():logits=model(ids,use_cache=False).logits[0,-1].float()
 receipt['fp16']={'finite_logits':int(torch.isfinite(logits).sum()),'logit_count':logits.numel(),'argmax':int(logits.argmax()),'stages':stages}
 del logits
 for h in handles:h.remove()
 # Precision change is diagnostic only. No revision or output from this branch
 # may be used as the frozen experiment or pooled into its scores.
 gpu_guard();model.float();torch.cuda.empty_cache()
 gpu_guard()
 with torch.inference_mode():logits=model(ids,use_cache=False).logits[0,-1].float()
 receipt['float32_diagnostic']={'finite_logits':int(torch.isfinite(logits).sum()),'logit_count':logits.numel(),'argmax':int(logits.argmax()),'next_token':tok.decode([int(logits.argmax())]),'max_abs':float(logits.abs().max())}
 receipt['status']='DIAGNOSTIC_COMPLETED_NO_BENCHMARK'
except Exception as e:
 receipt.update(status='DIAGNOSTIC_FAILED',error=str(e));traceback.print_exc()
finally:
 atomic_json(root/'evidence/local_numeric_diagnostic.json',receipt);print(json.dumps(receipt,indent=2))
