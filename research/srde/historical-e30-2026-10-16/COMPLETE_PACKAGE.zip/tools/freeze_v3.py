import sys,json,pathlib,datetime,zipfile,base64,hashlib,re
workspace=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(workspace/'e30_repair_v3/source'))
import e30_integrity as i,e30_core as c
root=workspace/'e30_repair_v3'
freeze={'repair_id':i.REPAIR_ID,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'before_main_scoring':True,'files':i.source_manifest(),
'corpora':{'main':c.data()['sha256'],'confirmation':c.data(c.CONFIRM_SEEDS)['sha256']},
'model_revision':i.MODEL_REVISION,'original_zip_sha256':'8f5c15809e59574ec6d5da15e28c81b0075f15ef7f195bc6f3ba0a9a9f2950e8'}
i.atomic_json(root/'FREEZE.json',freeze)
dest=workspace/'E30_REPAIRED_v3_FROZEN.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(workspace)))
ph=i.file_sha(dest);payload=base64.b64encode(dest.read_bytes()).decode()
np=workspace/'FACO_SRDE_E30_REPAIRED_v3.ipynb';nb=json.loads(np.read_text())
setup="import base64,hashlib,zipfile,io,pathlib,json,subprocess,sys\nblob=base64.b64decode('"+payload+"')\nassert hashlib.sha256(blob).hexdigest()=='"+ph+"'\nzipfile.ZipFile(io.BytesIO(blob)).extractall('/content')\nroot=pathlib.Path('/content/e30_repair_v3')\nlock=json.loads((root/'dependencies.lock.json').read_text())\nrequirements=[n+'=='+v for n,v in lock['packages'].items()]\nsubprocess.run([sys.executable,'-m','pip','install','--index-url','https://pypi.org/simple',*requirements],check=True)\nprint('Restart session before running the next cell if torch was already imported. Frozen package SHA256: "+ph+"')\n"
nb['cells'][2]['source']=setup.splitlines(True);np.write_text(json.dumps(nb,indent=1)+'\n')
receipt={'freeze_sha256':i.file_sha(root/'FREEZE.json'),'package_sha256':ph,'notebook_sha256':i.file_sha(np)}
i.atomic_json(workspace/'evidence/freeze_v3_receipt.json',receipt);print(json.dumps(receipt,indent=2))
