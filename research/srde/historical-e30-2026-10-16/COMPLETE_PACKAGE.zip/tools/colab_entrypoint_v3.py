"""Colab UI wrapper: isolated frozen worker + verified external checkpoint saves.
Run this code in Colab's notebook kernel, not in the isolated model interpreter.
"""
import os
import json
import hashlib
import pathlib
import subprocess
from google.colab import files

WORKER = r'''
import sys,time,pathlib,json,os,subprocess,traceback
sys.path.insert(0,'/content/e30_repair_v3/source')
from e30_integrity import atomic_json,append_row,verify_freeze
from e30_run_model import load_backend,run,strictly_grade,MODEL_DEFAULT,gpu_guard
from e30_campaign import checkpoint_export
root=pathlib.Path('/content/colab_results_v3');root.mkdir(exist_ok=True)
def export(stage,n):
    z=checkpoint_export(root,stage,n,False)
    ack=z.with_suffix('.ack')
    print('TRANSFER_REQUIRED '+json.dumps({'path':str(z),'ack':str(ack),'sha256':__import__('hashlib').sha256(z.read_bytes()).hexdigest()}),flush=True)
    while not ack.exists():time.sleep(.25)
    if ack.read_text().strip()!='SAVED':raise RuntimeError('Checkpoint not acknowledged')
    append_row(root/'durability_receipts.jsonl',{'stage':stage,'n':n,'export':z.name,'ack':'SAVED'})
try:
    verify_freeze();gpu_guard()
    free=int(subprocess.check_output(['nvidia-smi','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
    if free<8192:raise RuntimeError('Under 8 GiB free before model load')
    t=time.perf_counter();backend=load_backend(MODEL_DEFAULT)
    count,infer,runtime=backend
    atomic_json(root/'startup_cost.json',{'load_seconds':time.perf_counter()-t,'runtime':runtime})
    smoke=root/'smoke.json'
    if smoke.exists():
        prior=json.loads(smoke.read_text())
        if prior['runtime']!=runtime:raise RuntimeError('Existing smoke runtime identity differs; use a new results directory')
        rr=prior['result'];grade=strictly_grade(rr['raw'],rr['ended'],'RABCDEFG')
        if prior['grade']!=grade:raise RuntimeError('Saved smoke grade differs from recomputed grade')
        print('SMOKE_RESUMED_WITHOUT_NEW_MODEL_CALL',flush=True)
    else:
        gpu_guard()
        rr=infer({'question':'What is the current route marker for SMOKE-C00 at tick 300?'},'[D0000] SMOKE-C00 route=RABCDEFG valid=[100,1000) origin=official verification=signed inherits=-')
        grade=strictly_grade(rr['raw'],rr['ended'],'RABCDEFG')
        atomic_json(smoke,{'scope':'Dedicated smoke; excluded from benchmark','result':rr,'grade':grade,'runtime':runtime})
    print('SMOKE_RESULT '+json.dumps(grade),flush=True)
    export('smoke',1)
    if grade['status'] not in ('CORRECT','WRONG'):raise RuntimeError('Smoke structurally invalid; no preflight/main')
    for mode,folder in [('preflight','preflight'),('standard','main'),('confirmation','confirmation')]:
        def cb(out,n):
            if n%80==0:export(folder,n)
        report=run(root/folder,mode,preflight=root/'preflight' if mode!='preflight' else None,platform_name='colab',backend=backend,checkpoint_callback=cb)
        print('STAGE_COMPLETED '+json.dumps({'stage':folder,'status':report['status'],'calls':report['completed_calls']}),flush=True)
        export(folder,report['completed_calls'])
    print('CAMPAIGN_COMPLETED',flush=True)
except Exception as e:
    append_row(root/'failures.jsonl',{'type':type(e).__name__,'error':str(e)})
    traceback.print_exc();export('failure',0);raise
'''

root=pathlib.Path('/content/e30_repair_v3')
assert hashlib.sha256(pathlib.Path('/content/E30_REPAIRED_v3_FROZEN.zip').read_bytes()).hexdigest()=='f54a7aa865049a9c8d7771372729f8a8814e117994eff499077a38935255cc9a'
worker=pathlib.Path('/content/e30_guarded_worker_v3.py');worker.write_text(WORKER)
env=os.environ.copy()
env.update(HF_HOME='/content/e30_model_cache',TRANSFORMERS_CACHE='/content/e30_model_cache',E30_MODEL_CACHE='/content/e30_model_cache/hub',HF_HUB_DISABLE_TELEMETRY='1',CUBLAS_WORKSPACE_CONFIG=':4096:8')
process=subprocess.Popen(['/content/e30_runtime_v3/bin/python','-u',str(worker)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
log=pathlib.Path('/content/colab_worker_v3.log')
with log.open('a') as record:
    for line in process.stdout:
        record.write(line);record.flush()
        print(line,end='',flush=True)
        if line.startswith('TRANSFER_REQUIRED '):
            item=json.loads(line.split(' ',1)[1]);path=pathlib.Path(item['path'])
            assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
            files.download(str(path))
            answer=input('Verify this checkpoint ZIP is saved outside Colab, then type SAVED: ')
            if answer.strip()!='SAVED':raise RuntimeError('External save not confirmed; worker remains paused')
            pathlib.Path(item['ack']).write_text('SAVED')
rc=process.wait()
print('WORKER_EXIT',rc)
if rc:raise RuntimeError('Frozen worker failed; retain downloaded evidence')
