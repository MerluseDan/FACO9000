"""Validate and compare completed E30 local/Colab receipts, preserving all rows."""
import argparse,json,pathlib,sys,statistics
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'e30_repair_v3/source'))
from e30_run_model import strictly_grade,summarize,selected_tasks
from e30_core import data,MAIN_SEEDS,CONFIRM_SEEDS
from e30_integrity import file_sha,verify_freeze

def load(folder,mode):
 p=pathlib.Path(folder);report=json.loads((p/'model_run.json').read_text())
 if report['status']!='REAL_LLM_COMPLETED' or not report['full_run']:raise ValueError(f'{p}: not a completed real model stage')
 if report['checkpoint_sha256']!=file_sha(p/'model_rows.jsonl'):raise ValueError('Checkpoint digest mismatch')
 rows=[json.loads(line) for line in (p/'model_rows.jsonl').read_text().splitlines()]
 expected={(t['id'],m) for w,t,m in selected_tasks(data(CONFIRM_SEEDS if mode=='confirmation' else MAIN_SEEDS),mode)}
 keyed={(r['task_id'],r['method']):r for r in rows}
 if len(keyed)!=len(rows) or set(keyed)!=expected:raise ValueError('Invalid completion keyset')
 for r in rows:
  grade=strictly_grade(r['model_output'],r['ended'],r['gold'])
  if any(r[k]!=v for k,v in grade.items()):raise ValueError('Saved grade differs from recomputed grade')
 return report,keyed

def compare(local,colab,mode):
 a,ar=load(local,mode);b,br=load(colab,mode)
 ai=a['protocol']['base_identity'];bi=b['protocol']['base_identity']
 frozen=verify_freeze()
 if ai['freeze_sha256']!=bi['freeze_sha256']:raise ValueError('Different frozen protocol/code')
 for k in ('model_id','model_revision','tokenizer_revision','methods','evidence_token_budget','max_new_tokens'):
  if ai[k]!=bi[k]:raise ValueError('Unmatched study parameter '+k)
 if ai['runtime']['dependencies']!=bi['runtime']['dependencies']:raise ValueError('Different dependency versions')
 for k in ar:
  for f in ('prompt_sha256','input_prompt_sha256','gold','evidence_tokens'):
   if ar[k][f]!=br[k][f]:raise ValueError(f'Different paired prompt/gold: {k} {f}')
 methods={}
 for m in ai['methods']:
  x=[ar[k] for k in ar if k[1]==m];y=[br[k] for k in ar if k[1]==m]
  def metrics(rs):
   return {'n':len(rs),'correct':sum(r['correct'] for r in rs),
    'accuracy':statistics.mean(r['correct'] for r in rs),
    'mean_inference_seconds':statistics.mean(r['seconds'] for r in rs),
    'mean_retrieval_seconds':statistics.mean(r['retrieval_seconds'] for r in rs),
    'mean_state_seconds':statistics.mean(r['state_preprocessing_seconds'] for r in rs),
    'peak_allocated_bytes':max(r['peak_allocated_bytes'] for r in rs),
    'peak_reserved_bytes':max(r['peak_reserved_bytes'] for r in rs)}
  methods[m]={'local':metrics(x),'colab':metrics(y),
   'identical_output_token_sequences':sum(u['generated_token_ids']==v['generated_token_ids'] for u,v in zip(x,y)),
   'different_correctness_keys':[list(k) for k in ar if k[1]==m and ar[k]['correct']!=br[k]['correct']]}
 return {'mode':mode,'status':'PAIRED_COMPLETED_VALIDATED','methods':methods,
  'runtime_differences':{k:{'local':ai['runtime'].get(k),'colab':bi['runtime'].get(k)} for k in set(ai['runtime'])|set(bi['runtime']) if ai['runtime'].get(k)!=bi['runtime'].get(k)},
  'local_primary':summarize(list(ar.values()))['paired_srde_minus_graph_state'],
  'colab_primary':summarize(list(br.values()))['paired_srde_minus_graph_state'],
  'scope':'Real model over synthetic same-generator software memory. No real-world validation or detector replication.'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--local',required=True);p.add_argument('--colab',required=True)
 p.add_argument('--mode',choices=['standard','confirmation'],required=True);p.add_argument('--out',required=True)
 a=p.parse_args();result=compare(a.local,a.colab,a.mode)
 pathlib.Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
