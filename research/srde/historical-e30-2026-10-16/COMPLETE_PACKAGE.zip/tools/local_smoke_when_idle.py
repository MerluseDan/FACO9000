"""Dedicated local CUDA smoke. Refuse while any unrelated LLM server is resident.
No benchmark questions or scores are used. Do not execute after the prior review
denial until current permission/occupancy evidence permits the retry.
"""
import sys,pathlib,time,json,subprocess,traceback
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'e30_repair_v2/source'))
from e30_integrity import verify_freeze,atomic_json
from e30_run_model import load_backend,strictly_grade,MODEL_DEFAULT,gpu_guard
receipt={'scope':'Dedicated smoke only, excluded from preflight/main/confirmation'}
try:
 occupancy=subprocess.run(['nvidia-smi','pmon','-c','3','-s','um'],capture_output=True,text=True,check=True).stdout
 receipt['occupancy']=occupancy
 if 'llama-server' in occupancy:raise RuntimeError('Unrelated llama-server remains resident; defer E30 smoke')
 receipt['freeze']=verify_freeze()
 gpu_guard() # Explicit guard immediately before loader; loader guards again before model load.
 start=time.perf_counter();count,infer,runtime=load_backend(MODEL_DEFAULT)
 receipt['backend_load_seconds']=time.perf_counter()-start;receipt['runtime']=runtime
 task={'question':'What is the current route marker for SMOKE-C00 at tick 300?'}
 ctx='[D0000] SMOKE-C00 route=RABCDEFG valid=[100,1000) origin=official verification=signed inherits=-'
 gpu_guard() # Guard immediately before the single generation.
 result=infer(task,ctx);receipt['result']=result
 receipt['grade']=strictly_grade(result['raw'],result['ended'],'RABCDEFG')
 receipt['status']='SMOKE_EXECUTED'
except Exception as e:
 receipt.update(status='SMOKE_BLOCKED_OR_FAILED',error=str(e),error_type=type(e).__name__)
 traceback.print_exc()
finally:
 atomic_json(root/'evidence/local_smoke.json',receipt)
 print(json.dumps(receipt,indent=2))
