"""Pinned-byte + tokenizer/prompt smoke only. NO MODEL INFERENCE, NO GPU use."""
import sys,pathlib,json,time,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'e30_repair_v2/source'))
from e30_integrity import verify_freeze,atomic_json,file_sha,dependency_versions,MODEL_REVISION
from e30_core import data,MAIN_SEEDS,CONFIRM_SEEDS,sha
from e30_run_model import selected_tasks,prepare_expected
from transformers import AutoTokenizer
start=time.perf_counter();freeze=verify_freeze();deps=dependency_versions()
snap=root/'model_cache/hub/models--Qwen--Qwen2.5-1.5B-Instruct/snapshots'/MODEL_REVISION
expected_files=json.loads((root/'e30_repair_v2/MODEL_FILES.json').read_text())['files']
actual_files={name:file_sha(snap/name) for name in expected_files}
assert actual_files==expected_files
print('All 8 pinned model/tokenizer file hashes match',flush=True)
tok=AutoTokenizer.from_pretrained(str(snap),local_files_only=True,trust_remote_code=False)
def count(text):return len(tok.encode(text,add_special_tokens=False))
def chat_hash(task,ctx):
 from e30_core import prompt
 p=prompt(task,ctx)
 ids=tok.apply_chat_template([{'role':'system','content':p['system']},{'role':'user','content':p['user']}],tokenize=True,add_generation_prompt=True)
 return sha(ids)
count.chat_hash=chat_hash
all_stats={}
for mode,seeds in [('preflight',MAIN_SEEDS),('standard',MAIN_SEEDS),('confirmation',CONFIRM_SEEDS)]:
 expected=prepare_expected(selected_tasks(data(seeds),mode),count)
 manifest=[{'task_id':k[0],'method':k[1],**{f:v[f] for f in ['world','scenario','gold','prompt_sha256','input_prompt_sha256','evidence_tokens']}} for k,v in expected.items()]
 atomic_json(root/'evidence'/(mode+'_expected_prompts.json'),manifest)
 stats={'calls':len(expected),'maximum_evidence_tokens':max(x['evidence_tokens'] for x in expected.values()),
   'minimum_evidence_tokens':min(x['evidence_tokens'] for x in expected.values()),'prompt_manifest_sha256':file_sha(root/'evidence'/(mode+'_expected_prompts.json'))}
 all_stats[mode]=stats;print(mode,stats,flush=True)
atomic_json(root/'evidence/pre_run_cpu_audit.json',{'status':'PINNED_BYTES_AND_TOKENIZER_SMOKE_PASS_NO_MODEL_INFERENCE',
 'freeze_sha256':file_sha(root/'e30_repair_v2/FREEZE.json'),'model_files':actual_files,'dependencies':deps,
 'tokenizer':type(tok).__name__,'stages':all_stats,'seconds':time.perf_counter()-start,
 'gpu_used':False,'model_calls':0})
